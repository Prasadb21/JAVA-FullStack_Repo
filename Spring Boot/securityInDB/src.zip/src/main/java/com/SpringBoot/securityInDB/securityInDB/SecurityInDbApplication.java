package com.SpringBoot.securityInDB.securityInDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityInDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityInDbApplication.class, args);
	}

}
